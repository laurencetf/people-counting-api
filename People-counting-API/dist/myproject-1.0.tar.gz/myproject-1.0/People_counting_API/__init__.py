"""
Package for People_counting_API.
"""
