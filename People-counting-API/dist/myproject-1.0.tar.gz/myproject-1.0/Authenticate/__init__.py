"""
Package for Authenticate.
"""
